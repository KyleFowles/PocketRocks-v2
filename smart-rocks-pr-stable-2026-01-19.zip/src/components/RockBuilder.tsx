/* ============================================================
   FILE: src/components/RockBuilder.tsx

   SCOPE:
   Rock Builder (Steps 1–5)
   - Step 1 copy polish:
     1) Remove "Back" button on Step 1
     2) Change header text to: "Start with a goal…"
   - Keeps:
     - Step 1 AI panel logic as-is (handled inside StepDraft)
     - Autosave + AI flow
     - Final assembly on Step 5 entry

   STABILITY FIXES (HIGH VISIBILITY):
   - RockBuilder can now work even if parent only passes initialRock
     (it derives uid + rockId from initialRock as a fallback)
   - Removes React warning about mixing padding + paddingBottom
   - Step 5 "Continue" now navigates to /dashboard (so it actually does something)
   ============================================================ */

"use client";

import React, { useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";

import { Button } from "@/components/Button";
import StepDraft from "@/components/rock/StepDraft";
import StepSmart from "@/components/rock/StepSmart";
import StepMetrics from "@/components/rock/StepMetrics";
import StepMilestones from "@/components/rock/StepMilestones";
import { createRockWithId, updateRock } from "@/lib/rocks";

import type { AiSuggestion, BannerMsg, Props, Step } from "./rockBuilder/types";
import {
  clampStep,
  devError,
  safeStr,
  safeTrim,
  stableStringify,
  stripUndefinedDeep,
} from "./rockBuilder/utils";
import { stepName, styles } from "./rockBuilder/uiStyles";
import { assembleFinalRock, getFinalAssemblyKey } from "./rockBuilder/finalAssembler";

export default function RockBuilder({ uid, rockId, initialRock }: Props) {
  const router = useRouter();

  // ---------------------------------------------------------------------------
  // IMPORTANT: Parent pages sometimes render <RockBuilder initialRock={...} />
  // without passing uid/rockId props. So we derive stable fallbacks here.
  // ---------------------------------------------------------------------------
  const effectiveUid = useMemo(() => {
    const fromProp = safeTrim(uid);
    if (fromProp) return fromProp;

    const fromRockUserId = safeTrim((initialRock as any)?.userId);
    if (fromRockUserId) return fromRockUserId;

    const fromRockOwnerId = safeTrim((initialRock as any)?.ownerId);
    if (fromRockOwnerId) return fromRockOwnerId;

    return "";
  }, [uid, initialRock]);

  const effectiveRockId = useMemo(() => {
    const fromProp = safeTrim(rockId);
    if (fromProp) return fromProp;

    const fromInitial = safeTrim((initialRock as any)?.id);
    if (fromInitial) return fromInitial;

    return "";
  }, [rockId, initialRock]);

  const [step, setStep] = useState<Step>(() => clampStep((initialRock as any)?.step));

  const [rock, setRock] = useState<any>(() => ({
    ...(initialRock || {}),
    id: effectiveRockId,
    userId: effectiveUid,
    metrics: Array.isArray((initialRock as any)?.metrics) ? (initialRock as any).metrics : [],
    milestones: Array.isArray((initialRock as any)?.milestones) ? (initialRock as any).milestones : [],
  }));

  const [saveState, setSaveState] = useState<"idle" | "saving" | "saved" | "failed">("idle");
  const [saveError, setSaveError] = useState<string | null>(null);

  const [draftBanner, setDraftBanner] = useState<BannerMsg>(null);

  const aliveRef = useRef(true);
  const saveTimer = useRef<any>(null);
  const lastPatchRef = useRef<any>(null);
  const lastPatchKeyRef = useRef<string>("");

  const saveSeqRef = useRef(0);
  const createdRef = useRef<boolean>(false);
  const userNavigatedStepRef = useRef(false);

  const lastAssembledKeyRef = useRef<string>("");

  const [aiLoading, setAiLoading] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);

  useEffect(() => {
    aliveRef.current = true;
    return () => {
      aliveRef.current = false;
      if (saveTimer.current) clearTimeout(saveTimer.current);
    };
  }, []);

  useEffect(() => {
    userNavigatedStepRef.current = false;
    lastAssembledKeyRef.current = "";
  }, [effectiveRockId]);

  useEffect(() => {
    setRock((prev: any) => ({
      ...(prev || {}),
      ...(initialRock || {}),
      id: effectiveRockId,
      userId: effectiveUid,
      metrics: Array.isArray((initialRock as any)?.metrics)
        ? (initialRock as any).metrics
        : prev?.metrics ?? [],
      milestones: Array.isArray((initialRock as any)?.milestones)
        ? (initialRock as any).milestones
        : prev?.milestones ?? [],
    }));

    if (!userNavigatedStepRef.current && initialRock && (initialRock as any).step !== undefined) {
      setStep(clampStep((initialRock as any).step));
    }
  }, [effectiveRockId, effectiveUid, initialRock]);

  useEffect(() => {
    const hasDoc =
      !!initialRock &&
      !!safeTrim((initialRock as any)?.userId || (initialRock as any)?.ownerId) &&
      !!safeTrim((initialRock as any)?.id || effectiveRockId);
    createdRef.current = !!hasDoc;
  }, [initialRock, effectiveRockId]);

  const title = useMemo(() => safeStr(rock?.title) || "Rock", [rock?.title]);
  const draft = useMemo(() => safeStr(rock?.draft), [rock?.draft]);

  const hasDraftContent = useMemo(() => {
    return safeTrim(rock?.title).length > 0 || safeTrim(rock?.draft).length > 0;
  }, [rock?.title, rock?.draft]);

  const suggestedImprovement = useMemo(
    () => safeStr(rock?.suggestedImprovement),
    [rock?.suggestedImprovement]
  );

  async function ensureCreatedIfNeeded(baseData?: any) {
    if (createdRef.current) return;

    const payload = stripUndefinedDeep({
      ...(baseData || {}),
      id: effectiveRockId,
      userId: effectiveUid,
      step: clampStep(baseData?.step),
      title: safeStr(baseData?.title ?? rock?.title),
      draft: safeStr(baseData?.draft ?? rock?.draft),
      metrics: Array.isArray(baseData?.metrics ?? rock?.metrics) ? baseData?.metrics ?? rock?.metrics : [],
      milestones: Array.isArray(baseData?.milestones ?? rock?.milestones)
        ? baseData?.milestones ?? rock?.milestones
        : [],
    });

    await createRockWithId(effectiveUid, effectiveRockId, payload);
    createdRef.current = true;
  }

  async function persistPatchNow(patch: any) {
    const cleaned = stripUndefinedDeep(patch || {});
    if (!cleaned || (typeof cleaned === "object" && Object.keys(cleaned).length === 0)) return;

    await ensureCreatedIfNeeded(cleaned);
    await updateRock(effectiveUid, effectiveRockId, cleaned);
  }

  function scheduleSave(patch: any) {
    const cleaned = stripUndefinedDeep(patch || {});
    const patchKey = stableStringify(cleaned);

    if (!cleaned || (typeof cleaned === "object" && Object.keys(cleaned).length === 0)) return;
    if (patchKey && patchKey === lastPatchKeyRef.current) return;

    lastPatchKeyRef.current = patchKey;
    lastPatchRef.current = cleaned;

    if (aliveRef.current) {
      setSaveError(null);
      setSaveState("saving");
    }

    if (saveTimer.current) clearTimeout(saveTimer.current);

    const mySeq = ++saveSeqRef.current;

    saveTimer.current = setTimeout(async () => {
      try {
        const toSave = lastPatchRef.current || {};
        await persistPatchNow(toSave);

        if (!aliveRef.current) return;
        if (mySeq !== saveSeqRef.current) return;

        setSaveState("saved");
      } catch (e: any) {
        devError("[RockBuilder] persistPatchNow failed:", e);

        if (!aliveRef.current) return;
        if (mySeq !== saveSeqRef.current) return;

        setSaveState("failed");
        setSaveError(e?.message || "Save failed.");
      }
    }, 450);
  }

  function goToStep(target: Step) {
    userNavigatedStepRef.current = true;
    setStep(() => {
      scheduleSave({ step: target });
      return target;
    });
  }

  function nextStep() {
    userNavigatedStepRef.current = true;
    setStep((s) => {
      const ns = s < 5 ? ((s + 1) as Step) : s;
      scheduleSave({ step: ns });
      return ns;
    });
  }

  function prevStep() {
    userNavigatedStepRef.current = true;
    setStep((s) => {
      const ps = s > 1 ? ((s - 1) as Step) : s;
      scheduleSave({ step: ps });
      return ps;
    });
  }

  const canDraftInteract = useMemo(() => {
    const sessionUid = safeTrim(effectiveUid);

    // In this app, the client state uses userId (not ownerId).
    // The server may return ownerId, so we accept either.
    const rockUserId = safeTrim(rock?.userId);
    const rockOwnerId = safeTrim(rock?.ownerId);

    if (!sessionUid) return false;
    if (!safeTrim(effectiveRockId)) return false;

    // If the rock is already tied to a user, it must match the session.
    const bound = rockUserId || rockOwnerId;
    if (bound && bound !== sessionUid) return false;

    return true;
  }, [effectiveUid, effectiveRockId, rock?.userId, rock?.ownerId]);

  async function continueFromDraftExplicit() {
    if (!canDraftInteract) {
      setDraftBanner({
        kind: "error",
        text: "You need to be signed in (or Guest mode must provide a user id) before saving.",
      });
      return;
    }

    if (!hasDraftContent) {
      setDraftBanner({ kind: "error", text: "Add a title or a draft statement first." });
      return;
    }

    setDraftBanner(null);

    try {
      setSaveState("saving");
      setSaveError(null);

      await persistPatchNow({
        title: safeStr(rock?.title),
        draft: safeStr(rock?.draft),
        step: 2,
      });

      if (!aliveRef.current) return;

      setSaveState("saved");
      setStep(2);
    } catch (e: any) {
      if (!aliveRef.current) return;

      setSaveState("failed");
      setSaveError(e?.message || "Save failed.");
      setDraftBanner({ kind: "error", text: e?.message || "Save failed." });
    }
  }

  async function improveWithAiOption3() {
    if (!canDraftInteract) {
      setDraftBanner({
        kind: "error",
        text: "AI can’t run yet because the Rock isn’t tied to a user/session. Sign in (or ensure Guest mode creates a user id), then try again.",
      });
      return;
    }

    const d = safeTrim(rock?.draft);
    const t = safeTrim(rock?.title);

    if (!d && !t) {
      setDraftBanner({ kind: "error", text: "Add a title or a draft statement first." });
      return;
    }

    setAiLoading(true);
    setAiError(null);
    setDraftBanner(null);

    try {
      setSaveState("saving");
      await persistPatchNow({
        title: safeStr(rock?.title),
        draft: safeStr(rock?.draft),
        step: 1,
      });

      const res = await fetch("/api/rock-suggest", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ draft: safeStr(rock?.draft), title: safeStr(rock?.title) }),
      });

      if (!res.ok) throw new Error(`AI request failed (${res.status}).`);

      const data = await res.json();

      const suggestions: AiSuggestion[] = Array.isArray((data as any)?.suggestions)
        ? (data as any).suggestions
        : Array.isArray(data)
          ? (data as any)
          : [];

      const top = safeTrim((suggestions as any)?.[0]?.text);
      if (!top) throw new Error("AI did not return a suggestion.");

      // Save suggestion WITHOUT overwriting the user’s draft
      setRock((prev: any) => ({ ...(prev || {}), suggestedImprovement: top }));
      await persistPatchNow({ suggestedImprovement: top });

      if (!aliveRef.current) return;

      setSaveState("saved");
      setDraftBanner({ kind: "ok", text: "AI suggestion added." });
    } catch (e: any) {
      devError("[RockBuilder] improveWithAiOption3 failed:", e);

      if (!aliveRef.current) return;

      setSaveState("failed");
      const msg = e?.message || "AI failed. Try again in a moment.";
      setSaveError(msg);
      setAiError(msg);
      setDraftBanner({ kind: "error", text: msg });
    } finally {
      if (aliveRef.current) setAiLoading(false);
    }
  }

  function applyAiSuggestionToDraft() {
    const ai = safeTrim(suggestedImprovement);
    if (!ai) return;

    setRock((prev: any) => ({ ...(prev || {}), draft: ai }));
    scheduleSave({ draft: ai });

    setDraftBanner({ kind: "ok", text: "Draft replaced with AI suggestion." });
  }

  function buildFinalFromSmart() {
    const s = safeTrim(rock?.smart?.specific);
    const m = safeTrim(rock?.smart?.measurable);
    const t = safeTrim(rock?.smart?.timebound);

    const base = s || safeTrim(rock?.suggestedImprovement) || safeTrim(rock?.draft) || title;
    const metric = m ? ` (${m})` : "";
    const due = t ? ` — Due ${t}` : "";

    const final = `${base}${metric}${due}`.trim();

    setRock((prev: any) => ({ ...(prev || {}), finalStatement: final }));
    scheduleSave({ finalStatement: final });
    goToStep(5);
  }

  // FINAL ROCK ASSEMBLER (runs on Step 5 entry)
  useEffect(() => {
    if (step !== 5) return;

    const key = getFinalAssemblyKey(rock);
    const existingFinal = safeTrim(rock?.finalStatement);

    const storedKey = safeTrim(rock?.finalAssemblyKey);
    const canAutoReplace = !existingFinal || (storedKey && storedKey === lastAssembledKeyRef.current);

    if (!canAutoReplace) return;
    if (storedKey === key && existingFinal) return;

    const assembled = assembleFinalRock(rock);

    setRock((prev: any) => ({
      ...(prev || {}),
      finalStatement: assembled,
      finalAssemblyKey: key,
    }));

    lastAssembledKeyRef.current = key;

    scheduleSave({ finalStatement: assembled, finalAssemblyKey: key });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [step]);

  const footerPrimaryLabel = useMemo(() => {
    if (step === 1) return "Continue to SMART";
    if (step === 5) return "Done";
    return "Continue";
  }, [step]);

  async function footerPrimaryAction() {
    if (step === 1) {
      await continueFromDraftExplicit();
      return;
    }

    if (step === 5) {
      router.push("/dashboard");
      return;
    }

    nextStep();
  }

  const footerPrimaryDisabled = useMemo(() => {
    if (saveState === "saving" || aiLoading) return true;
    if (step === 1 && !hasDraftContent) return true;
    return false;
  }, [saveState, aiLoading, step, hasDraftContent]);

  const isStep1 = step === 1;

  return (
    <div style={styles.page}>
      <div style={styles.topBar}>
        <div>
          <div style={styles.brandRow}>
            <span style={styles.brandOrange}>Pocket</span>
            <span style={styles.brandWhite}>Rocks</span>
          </div>

          <div style={styles.crumb}>
            {isStep1 ? "DRAFT · Step 1 of 5" : `ROCK · ${stepName(step)}`}
          </div>
        </div>

        <div style={styles.savePillWrap}>
          {saveState === "saving" && <div style={styles.pill}>Saving…</div>}
          {saveState === "saved" && <div style={{ ...styles.pill, opacity: 0.65 }}>Saved</div>}
          {saveState === "failed" && (
            <div style={{ ...styles.pill, ...styles.pillFail }}>Save failed</div>
          )}
        </div>
      </div>

      <div style={styles.card}>
        {isStep1 ? (
          // IMPORTANT: Do NOT add paddingBottom here (it conflicts with styles.cardHdr padding shorthand).
          // Use a nested spacer instead to avoid the React warning overlay.
          <div style={styles.cardHdr}>
            <div style={{ marginBottom: 10 }}>
              <div style={{ ...styles.h1, fontSize: 22 }}>Start with a goal…</div>
              <div style={styles.subMuted}>Don’t overthink it. You’ll make it SMART next.</div>
            </div>
          </div>
        ) : (
          <div style={styles.cardHdr}>
            <div>
              <div style={styles.eyebrow}>{stepName(step)}</div>
              <div style={styles.h1}>{title}</div>
              {draft ? (
                <div style={styles.sub}>{draft}</div>
              ) : (
                <div style={styles.subMuted}>Build clear Rocks. Track them weekly.</div>
              )}
            </div>
          </div>
        )}

        {saveError && (
          <div style={styles.alert}>
            <div style={styles.alertTitle}>Heads up</div>
            <div style={styles.alertBody}>{saveError}</div>
          </div>
        )}

        {step === 1 && (
          <StepDraft
            rock={rock}
            onChange={(next) => setRock(next)}
            saving={saveState === "saving" || aiLoading}
            saved={saveState === "saved"}
            banner={draftBanner}
            canInteract={canDraftInteract && !aiLoading}
            onImproveWithAI={improveWithAiOption3}
            aiSuggestionText={suggestedImprovement}
            onApplyAiSuggestionToDraft={applyAiSuggestionToDraft}
          />
        )}

        {step === 2 && (
          <StepSmart
            rock={rock}
            onUpdateField={(path, value) => {
              const parts = path.split(".");
              setRock((prev: any) => {
                const next = { ...(prev || {}) };
                let cur: any = next;

                for (let i = 0; i < parts.length - 1; i++) {
                  const key = parts[i]!;
                  cur[key] = cur[key] && typeof cur[key] === "object" ? { ...cur[key] } : {};
                  cur = cur[key];
                }
                cur[parts[parts.length - 1]!] = value;
                return next;
              });

              const patch: any = {};
              let pcur: any = patch;
              for (let i = 0; i < parts.length - 1; i++) {
                const key = parts[i]!;
                pcur[key] = pcur[key] && typeof pcur[key] === "object" ? pcur[key] : {};
                pcur = pcur[key];
              }
              pcur[parts[parts.length - 1]!] = value;

              scheduleSave(patch);
            }}
            onBuildFinal={buildFinalFromSmart}
          />
        )}

        {step === 3 && (
          <StepMetrics
            value={safeStr(rock?.metricsText)}
            onChange={(next) => {
              setRock((prev: any) => ({ ...(prev || {}), metricsText: next }));
              scheduleSave({ metricsText: next });
            }}
          />
        )}

        {step === 4 && (
          <StepMilestones
            value={safeStr(rock?.milestonesText)}
            onChange={(next) => {
              setRock((prev: any) => ({ ...(prev || {}), milestonesText: next }));
              scheduleSave({ milestonesText: next });
            }}
          />
        )}

        <div style={styles.footer}>
          <div style={styles.footerLeft}>Step {step} of 5</div>

          <div style={styles.footerRight}>
            {/* Step 1 has no Back button (clean entry screen) */}
            {step !== 1 && (
              <Button type="button" onClick={prevStep}>
                Back
              </Button>
            )}

            <Button type="button" onClick={footerPrimaryAction} disabled={footerPrimaryDisabled}>
              {footerPrimaryLabel}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
